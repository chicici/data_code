import os
import datetime
import config_helper as ch
import lark_msg_helper as lark

class comm():

     # 获取sql文件目录
    def get_sql_base_dir(self,prex):

        sql_base_dir = os.path.dirname(os.path.abspath(__file__)).replace('script','sql')

        return sql_base_dir


     #获取催收库连接
    def get_database_conn_info(self,data_schema):
         config_file_path = os.path.join(
             os.path.dirname(os.path.dirname(os.path.abspath(__file__))).replace('script', 'config'), 'jdbc_config.ini')

         cf = ch.ReadConfig(config_file_path)

         dict_val = {}
         host = cf.get_config(data_schema, "database_ip")
         port = cf.get_config(data_schema, "database_port")
         user = cf.get_config(data_schema, "database_user")
         password = cf.get_config(data_schema, "database_password")
         database_name = cf.get_config(data_schema, "database_name")

         dict_val['host'] = host
         dict_val['port'] = port
         dict_val['user'] = user
         dict_val['password'] = password
         dict_val['database_name'] = database_name

         return dict_val

    # 预警地址
    def get_lark_msg_url(self):
         config_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))).replace('script','config'),'msg_config.ini')


         cf = ch.ReadConfig(config_file_path)

         lark_msg_url = cf.get_config("lark_msg", "lark_msg_url")

         return lark_msg_url


    # 发送预警消息
    def  send_lark_msg(self,msg):
            msg_url=self.get_lark_msg_url()
            feishu = lark.FeiShutalkChatbot(msg_url)
            feishu.send_text(msg)