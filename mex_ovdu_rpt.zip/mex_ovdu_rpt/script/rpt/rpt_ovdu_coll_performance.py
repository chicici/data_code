import  sys,os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import  pandas as pd
import comm as cm
import mysql_helper as myh

from urllib import parse
import  date_helper as dh

from sqlalchemy import create_engine


import rpt_base as rptb

class rpt_ovdu_coll_performance(rptb.rpt_base):

    def __init__(self,date_flag):
        if('Weekly'==date_flag):
            self.sql_file='rpt_ovdu_coll_performance_weekly.sql'
        elif('Daily'==date_flag):
            self.sql_file = "rpt_ovdu_coll_performance.sql"
        elif('HalfMonth'==date_flag):
            self.sql_file = "rpt_ovdu_coll_performance_halfmonth.sql"
        else:
            self.sql_file=''



    def  export_to_ovdu(self,date_list,date_flag):
        com = cm.comm()

        ovdu_database_schema = 'mex_pdl_ovdu'
        ovdu_database_dict = com.get_database_conn_info(ovdu_database_schema)

        dw_database_schema = 'data_warehouse'
        dw_database_dict = com.get_database_conn_info(dw_database_schema)



        dw_msql = myh.MysqlHelper(host=dw_database_dict['host'], port=int(dw_database_dict['port']), user=dw_database_dict['user'],
                               pwd=dw_database_dict['password'],
                               db='rpt_cal')
        query_sql = '''    
                           select
                           uuid() as id,
                           Period_Flag,
                           Period,
                           Dimensions,
                           Group_Flag,
                           Group_Name,
                           SrTeam_Leader,
                           Team_Leader,
                           JrTeam_Leader,
                           Collector,
                           Balance_Amt,
                           Repay_Amt,
                           Balance_Num,
                           Repay_Num,
                           now() as INST_TIME
                         from rpt_cal.rpt_ovdu_coll_performance
                         where  period_flag='{period_flag}'
                          and   Period='{biz_date}'
                       '''

        delete_sql = '''
                           delete from mex_pdl_ovdu.ovdu_coll_performance_rpt_dwd
                           where period_flag='{period_flag}'
                           and left(period,10)=left('{biz_date}',10)
                        '''

        if(date_list):
            for date in date_list:
                print('--------------------' + date + '--------------------------')

                print(query_sql.format(biz_date=date,period_flag=date_flag))
                try:

                    data_list=dw_msql.execQuery(query_sql.format(biz_date=date,period_flag=date_flag))

                    df=pd.DataFrame(data_list,columns=[
                                  "id",
                                  "Period_Flag",
                                  "Period",
                                  "Dimensions",
                                  "Group_Flag",
                                  "Group_Name",
                                  "SrTeam_Leader",
                                  "Team_Leader",
                                  "JrTeam_Leader",
                                  "Collector",
                                  "Balance_Amt",
                                  "Repay_Amt",
                                  "Balance_Num",
                                  "Repay_Num",
                                  "INST_TIME"
                        ])


                    target_host = ovdu_database_dict['host']
                    target_port = ovdu_database_dict['port']
                    target_user = ovdu_database_dict['user']
                    target_password = ovdu_database_dict['password']
                    target_db = ovdu_database_dict['database_name']
                    target_table='ovdu_coll_performance_rpt_dwd'
                    ovdu_msql = myh.MysqlHelper(host=target_host, port=int(target_port),
                                                user=target_user,
                                                pwd=target_password,
                                                db=target_db)

                    print(delete_sql.format(biz_date=date,period_flag=date_flag))
                    ovdu_msql.execNonQuery(delete_sql.format(biz_date=date,period_flag=date_flag))

                    connect = '''mysql+mysqldb://{target_user}:{target_password}@{target_host}:3306/{target_db}?charset=utf8''' .format(target_user=target_user,target_password=parse.quote_plus('pdl_yw!191@'),target_host=target_host,target_db=target_db)
                    #connect = '''mysql+mysqldb://{target_user}:{target_password}@{target_host}:3306/{target_db}?charset=utf8'''.format(target_user=target_user, target_password=target_password,target_host=target_host,target_db=target_db)
                    engine = create_engine(connect)
                    df.to_sql(target_table, engine, index=False, if_exists='append')
                    print("sync ovdu data  ok！！")


                except Exception as e:
                    com.send_lark_msg('同步数据到催收库执行失败,错误原因：' + str(e.args) + '，请及时处理')
                    print(e)
                    sys.exit(1)





if __name__ == "__main__":
    argv_len = len(sys.argv)

    begin_date=''
    end_date=''
    date_flag=''
    print(argv_len)
    if (argv_len>=2):
        date_flag = sys.argv[1]
        if(argv_len==3):
            try:
                pass
            except Exception as e:
                print('please input begin_date,end_date!!!')
                exit(0)
        elif(argv_len>3):
            begin_date = sys.argv[2]
            end_date = sys.argv[3]

    if(not  date_flag):
        date_flag='Daily'

    rpt = rpt_ovdu_coll_performance(date_flag)
    date_hepler=dh.DateHelper()
    date_list = date_hepler.get_multi_date_list(begin_date, end_date, date_flag)


    rpt.execute_script_multi(rpt.sql_file,begin_date, end_date, date_flag)

    rpt.export_to_ovdu(date_list,date_flag)









