import os,sys
from datetime import datetime
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import abc

import date_helper as dh
import mysql_helper as myh
import read_file_helper as  rfh
import comm as cm


class rpt_base():
    __metaclass__ = abc.ABCMeta


    def __init__(self,sql_file):
        self.sql_file=sql_file
        self.prex='rpt'

    # 计算代码执行时长
    def decorator(func):
        def wrapper(*kwargs):
            start = datetime.now()
            print('start:' + start.strftime('%Y-%m-%d %H:%M:%S'))
            print(len(kwargs))
            if(len(kwargs)==5):
                func(sql_file=kwargs[1], begin_date=kwargs[2], end_date=kwargs[3],date_flag=kwargs[4])
            else:
                func(sql_file=kwargs[1], begin_date=kwargs[2], end_date=kwargs[3])

            end = datetime.now()
            print('end:' + end.strftime('%Y-%m-%d %H:%M:%S'))
            print('代码运行时长:' + str((end - start).seconds) + 's')

        return wrapper

    # 执行SQL脚本
    @decorator
    def execute_script(sql_file,begin_date,end_date):

        date_helper=dh.DateHelper()
        date_list = date_helper.get_date_list(begin_date, end_date)

        fd = rpt_base(sql_file)

        com=cm.comm()
        base_dir = com.get_sql_base_dir(fd.prex)


        rf = rfh.ReadFileHelper()
        sql_item = rf.readSqlFile(base_dir, fd.sql_file)
        database_schema='data_warehouse'
        database_dict=com.get_database_conn_info(database_schema)
        msql = myh.MysqlHelper(host=database_dict['host'], port=int(database_dict['port']), user=database_dict['user'], pwd=database_dict['password'],
                               db='rpt_cal')

        for date in date_list:
            print('--------------------'+date+'--------------------------')
            for sql in sql_item:
                print(sql.format(biz_date=date))
                try:
                    msql.execNonQuery(sql.format(biz_date=date))
                except Exception as e:
                    com.send_lark_msg(sql_file + ' 执行失败,错误原因：' + str(e.args) + '，请及时处理')
                    print(e)
                    sys.exit(1)



    @decorator
    def execute_script_multi(sql_file, begin_date, end_date, date_flag):

        date_hepler = dh.DateHelper()
        date_list = date_hepler.get_multi_date_list(begin_date, end_date, date_flag)
        fd = rpt_base(sql_file)

        com = cm.comm()
        base_dir = com.get_sql_base_dir(fd.prex)

        rf = rfh.ReadFileHelper()
        sql_item = rf.readSqlFile(base_dir, fd.sql_file)
        database_schema = 'data_warehouse'
        database_dict = com.get_database_conn_info(database_schema)
        msql = myh.MysqlHelper(host=database_dict['host'], port=int(database_dict['port']), user=database_dict['user'],
                               pwd=database_dict['password'],
                               db='rpt_cal')

        for date in date_list:
            print('--------------------' + date + '--------------------------')

            for sql in sql_item:
                print(sql.format(biz_date=date))
                try:
                  msql.execNonQuery(sql.format(biz_date=date))

                except Exception as e:
                    com.send_lark_msg(sql_file + ' 执行失败,错误原因：' + str(e.args) + '，请及时处理')
                    print(e)
                    sys.exit(1)

