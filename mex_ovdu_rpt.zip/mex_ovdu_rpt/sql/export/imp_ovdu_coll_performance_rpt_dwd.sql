select
        uuid() as id,
        Period_Flag,
        Period,
        Dimensions,
        Group_Flag,
        Group_Name,
        SrTeam_Leader,
        Team_Leader,
        JrTeam_Leader,
        Collector,
        Balance_Amt,
        Repay_Amt,
        Balance_Num,
        Repay_Num,
        now() as INST_TIME
      from rpt_cal.rpt_ovdu_coll_performance
      where  Period>=date('{biz_date}')
       and   Period<date_add(date('{biz_date}'),INTERVAL 1 day)