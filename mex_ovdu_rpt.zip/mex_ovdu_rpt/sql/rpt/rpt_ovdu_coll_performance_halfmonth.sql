delete from rpt_cal.rpt_ovdu_coll_performance
where Period_Flag='HalfMonth'
        and left(period,10)=left('{biz_date}',10);


insert into rpt_cal.rpt_ovdu_coll_performance
select uuid(),'HalfMonth',
	'{biz_date}' re_mon,
	Dimensions,Group_Flag,Group_Name,SrTeam_Leader,Team_Leader,JrTeam_Leader,
	sum(Collector),
	sum(Balance_Amt),
	sum(Repay_Amt),
	sum(Balance_Num),
	sum(Repay_Num),
	now()
from
	rpt_ovdu_coll_performance
where
	period>=left('{biz_date}',10)
	and period<=right('{biz_date}',10)
	and period_flag='Daily'
	and Group_Flag<5
group by re_mon,Dimensions,Group_Flag,Group_Name,SrTeam_Leader,Team_Leader,JrTeam_Leader
union all
select uuid(),'HalfMonth',
	'{biz_date}' re_mon,
	Dimensions,Group_Flag,Group_Name,SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector,
	sum(Balance_Amt),
	sum(Repay_Amt),
	sum(Balance_Num),
	sum(Repay_Num),
	now()
from
	rpt_ovdu_coll_performance
	where
	    period>=left('{biz_date}',10)
	and period<=right('{biz_date}',10)
	and group_flag=5
	and period_flag='Daily'
group by re_mon,Dimensions,Group_Flag,Group_Name,SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector;