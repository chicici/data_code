
delete from  rpt_cal.rpt_ovdu_coll_performance
   where  Period='{biz_date}'
	and  period_flag='Daily';


INSERT into rpt_cal.rpt_ovdu_coll_performance
-- Daily
-- 取结清数算案件回款率（结清日期等于业务日期，则单子结清）
-- 将展期贷款纳入考虑 afterstat为10270004时，该单的应还金额和实还金额都记为curdt_repay_interest

-- ======================= Group 级 =====================================================================================
select uuid(),'Daily',al.*,now() from
(
select Date,Dimensions,
  1 as Flag,
  GroupName,
  null as SrTeam_Leader,
  null as Team_Leader,
  null as JrTeam_Leader,
  count(Collector_Name) Collector,
  sum(BalanceAmt)BalanceAmt,
  sum(CurdtRepayAmt)CurdtRepayAmt,
  sum(BalanceNum)BalanceNum,
  sum(CurdtRepayNum)CurdtRepayNum
from
(
-- Total===========================================================
select a.busi_dt Date,
  'Total' as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4

union all


-- Today and  History=============================================================
select a.busi_dt Date,
  TodayOrHis as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4

union all

-- New and Reloan==============================================================
select a.busi_dt Date,
  NewOrRe as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4

)base
left join
(
select SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector_No,Collector_Name
from dw_cal.dw_ovdu_org_rel_info
)org
on base.deal_person_no=org.Collector_No
group by 1,2,3,4,5,6,7


union all

-- ======================= Sr TL级 =====================================================================================

select Date,Dimensions,
  2 as Flag,
  GroupName,
  SrTeam_Leader,
  null as Team_Leader,
  null as JrTeam_Leader,
  count(Collector_Name) Collector,
  sum(BalanceAmt)BalanceAmt,
  sum(CurdtRepayAmt)CurdtRepayAmt,
  sum(BalanceNum)BalanceNum,
  sum(CurdtRepayNum)CurdtRepayNum
from
(
-- Total===========================================================
select a.busi_dt Date,
  'Total' as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4

union all

-- Today  and  History==========================================================
select a.busi_dt Date,
  TodayOrHis as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4


union all

-- New and  Reloan==============================================================
select a.busi_dt Date,
 NewOrRe as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4

)base
left join
(
select SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector_No,Collector_Name
from dw_cal.dw_ovdu_org_rel_info
)org
on base.deal_person_no=org.Collector_No
group by 1,2,3,4,5,6,7

union all

-- ======================= TL级 =====================================================================================

select Date,Dimensions,
  3 as Flag,
  GroupName,
  SrTeam_Leader,
  Team_Leader,
  null as JrTeam_Leader,
  count(Collector_Name) Collector,
  sum(BalanceAmt)BalanceAmt,
  sum(CurdtRepayAmt)CurdtRepayAmt,
  sum(BalanceNum)BalanceNum,
  sum(CurdtRepayNum)CurdtRepayNum
from
(
-- Total===========================================================
select a.busi_dt Date,
  'Total' as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4

union all

-- Today and History==========================================================
select a.busi_dt Date,
  TodayOrHis as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan') as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4


union all

-- New and Reloan==============================================================
select a.busi_dt Date,
  NewOrRe as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4

)base
left join
(
select SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector_No,Collector_Name
from dw_cal.dw_ovdu_org_rel_info
)org
on base.deal_person_no=org.Collector_No
group by 1,2,3,4,5,6,7

union all

-- =======================Jr TL级=====================================================================================

select Date,Dimensions,
  4 as Flag,
  GroupName,
  SrTeam_Leader,
  Team_Leader,
  JrTeam_Leader,
  count(Collector_Name) Collector,
  sum(BalanceAmt)BalanceAmt,
  sum(CurdtRepayAmt)CurdtRepayAmt,
  sum(BalanceNum)BalanceNum,
  sum(CurdtRepayNum)CurdtRepayNum
from
(
-- Total===========================================================
select a.busi_dt Date,
  'Total' as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4

union all

-- Today and  History==========================================================
select a.busi_dt Date,
  TodayOrHis as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4

union all

-- New and Reloan ==============================================================
select a.busi_dt Date,
  NewOrRe as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4


)base
left join
(
select SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector_No,Collector_Name
from dw_cal.dw_ovdu_org_rel_info
)org
on base.deal_person_no=org.Collector_No
group by 1,2,3,4,5,6,7



union all

-- =======================Collector级=====================================================================================
-- Date  Dimensions Flag  GroupName  Senior TL  Team_Leader  Junior TL  Collector  BalanceAmt  CurdtRepayAmt  RecoveryRateAmt_CurdtRepay  BalanceNum  CurdtRepayNum  RecoveryRateNum_CurdtRepay

select Date,Dimensions,
  5 as Flag,
  GroupName,
  SrTeam_Leader,Team_Leader,JrTeam_Leader,
  Collector_Name Collector,
  BalanceAmt,
  CurdtRepayAmt,
  BalanceNum,
  CurdtRepayNum
from
(
-- Total===========================================================
select a.busi_dt Date,
  'Total' as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a

group by 1,2,3,4

union all

-- Today and History==========================================================
select a.busi_dt Date,
  TodayOrHis as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4


union all

-- New and Reloan==============================================================
select a.busi_dt Date,
  NewOrRe as Dimensions,
  GroupName,
  a.deal_person_no,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_balance end),0)BalanceAmt,
  round(sum(case when after_stat='10270004' then curdt_repay_interest else curdt_repay end),0)CurdtRepayAmt,
  count(1)BalanceNum,
  sum(case when busi_dt=settle_dt then 1 else 0 end)CurdtRepayNum
from
(
select busi_dt, case_no, loan_no, due_dt, after_stat,
  if(cust_type='new','New','Reloan')  as NewOrRe,
  case
    when  ovdu_days>=1 and ovdu_days<=4 then 'M0 1-4'
    when  ovdu_days>=5 and ovdu_days<=12 then 'M0 5-12'
    when  ovdu_days>=13 and ovdu_days<=30 then 'M0 13-30'
    when ovdu_days <1 then 'Reminder'
    else 'M1' end as GroupName,
  case when date(last_div_tm)=busi_dt then 'Today' else 'History' end as TodayOrHis,
  settle_dt,
  deal_person_no,curdt_repay_interest,
  (balance_prin + balance_interest + curdt_repay_prin + curdt_repay_interest) curdt_balance,
  (curdt_repay_prin + curdt_repay_interest + curdt_repay_latefee) curdt_repay
from dw_cal.dwd_loan_fin_daily_info_d
where busi_dt='{biz_date}' and ovdu_days>=0 and deal_person_no is not null
-- and deal_person_no not like 'SysM%@lanaplus.%'
)a
group by 1,2,3,4

)base
left join
(
select distinct SrTeam_Leader,Team_Leader,JrTeam_Leader,Collector_No,Collector_Name
from dw_cal.dw_ovdu_org_rel_info
)org
on base.deal_person_no=org.Collector_No
)al;
