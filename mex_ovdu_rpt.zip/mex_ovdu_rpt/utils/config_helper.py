import configparser
import os, sys
import re


class ReadConfig:
    def __init__(self, filepath=None):
        configpath=''
        if filepath:
            configpath = filepath
        else:
            root_dir = os.path.dirname(os.path.abspath('.'))
            configpath = os.path.join(root_dir, "config.ini")
        
        content = open(configpath).read()
        content = re.sub(r"\xfe\xff","", content)
        content = re.sub(r"\xff\xfe","", content)
        content = re.sub(r"\xef\xbb\xbf","", content)
        open(configpath, 'w').write(content)

       
        self.cf = configparser.ConfigParser()
        self.cf.read(configpath)
        
        

        

    def get_config(self, section, item):
        value = self.cf.get(section, item)
        return value

# if __name__ == '__main__':
#     test = ReadConfig(os.path.abspath('config.ini') )
#     t = test.get_config("mex_pdl_loan_master","MEX_PDL_LOAN_MASTER_DATABASE_IP")
#     print(t)


# cf = configparser.ConfigParser()
# config_path=os.path.abspath('config.ini') #获取配置文件路径
#
# cf.read(config_path,encoding='utf-8')  # 读取配置文件，如果写文件的绝对路径，就可以不用os模块
#
# secs = cf.sections()  # 获取文件中所有的section(一个配置文件中可以有多个配置，如数据库相关的配置，邮箱相关的配置，                        每个section由[]包裹，即[section])，并以列表的形式返回
# print(secs)
#
# options=cf.options("mex_pdl_loan_master")
# print(options)

# options = cf.options("Mysql-Database")  # 获取某个section名为Mysql-Database所对应的键
# print(options)
#
# items = cf.items("Mysql-Database")  # 获取section名为Mysql-Database所对应的全部键值对
# print(items)
#
# host = cf.get("Mysql-Database", "host")  # 获取[Mysql-Database]中host对应的值
# print(host)
