from datetime import date, timedelta,datetime

import  calendar
import pandas as pd


class DateHelper():
    global DATE_FLAG_DAILY ,DATE_FLAG_WEEK,DATE_FLAG_HALF_MONTH,DATE_FLAG_MONTH,DATE_FLAG_YEAR

    DATE_FLAG_DAILY= 'Daily',
    DATE_FLAG_WEEK = 'Weekly',
    DATE_FLAG_HALF_MONTH = 'Half_Month',
    DATE_FLAG_MONTH = 'Month',
    DATE_FLAG_YEAR = 'Year'

    # 获取默认的开始时间
    def get_default_begin_date(self):
        return (datetime.now() + timedelta(hours=-1)).strftime("%Y-%m-%d")
    # 获取默认的结束时间
    def get_default_end_date(self):
        return (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")

    # 获取本周周一
    def get_default_weekday_begin_and_end(self):
        today=datetime.now().strftime("%Y-%m-%d")

        return self.get_weekday_begin_and_end(today)

    #获取输入时间所在周1和周7
    def get_weekday_begin_and_end(self, input_date):

        monday = datetime.strptime(input_date, '%Y-%m-%d').date()
        sunday = datetime.strptime(input_date, '%Y-%m-%d').date()

        one_day = timedelta(days=1)
        while monday.weekday() != 0:
            monday -= one_day
        while sunday.weekday() != 6:
            sunday += one_day

        return monday,sunday

    def get_weekday_list_begin_and_end(self,begin_date,end_date):

        """
                    :param begin_date: 开始时间
                    :param end_date: 结束时间
                    :param date_format: 时间格式化 默认为：%Y%m%d
                    :return: begin_date-end_date 中所有的周（周一日期_周日日期）
        """

        def_monday,def_sunday=self.get_default_weekday_begin_and_end()

        if (not begin_date):
                begin_date = def_monday.strftime("%Y-%m-%d")

        if (not end_date):
                end_date = def_sunday.strftime("%Y-%m-%d")

        date=datetime.strptime(begin_date, "%Y-%m-%d").date()
        end_date=datetime.strptime(end_date, "%Y-%m-%d").date()
        if(end_date.__ge__(date.today())):
            end_date=date.today()
        result_list=[]
        while date.__le__(end_date):
            date_str=date.strftime("%Y-%m-%d")
            b_monday, b_sunday = self.get_weekday_begin_and_end(date_str)
            date = (b_monday + timedelta(days=7))

            if(b_sunday.__ge__(end_date)):
                b_sunday=end_date
            result_list.append(str(b_monday)+'_'+str(b_sunday))
        return result_list


    def get_month_start_and_end(self,input_date):
        """
            :param begin_date: 开始时间
            :param end_date: 结束时间
            :param date_format: 时间格式化 默认为：%Y%m%d
            :return: begin_date-end_date 中所有的周（周一日期_周日日期）
        """
        biz_date=datetime.strptime(input_date, "%Y-%m-%d").date()

        begin_date=datetime(biz_date.year, biz_date.month, 1).strftime("%Y-%m-%d")
        end_date=datetime(biz_date.year, biz_date.month, calendar.monthrange(biz_date.year, biz_date.month)[1]).strftime("%Y-%m-%d")

        return str(begin_date)+'_'+end_date

    def get_month_list_start_and_end(self,begin_date,end_date):
        """
            :param begin_date: 开始时间
            :param end_date: 结束时间
            :param date_format: 时间格式化 默认为：%Y%m%d
            :return: begin_date-end_date 中所有的周（周一日期_周日日期）
        """
        date_list=[]
        list=self.get_date_list(begin_date,end_date)
        months=[]
        for date_str in list:
            mid_date=date_str[0:7]
            if(mid_date not  in months):
                months.append(mid_date)
                mid_date = mid_date + '-01'
                result=self.get_month_start_and_end(mid_date)
                date_list.append(result)

        return date_list


    def get_half_month_start_and_end(self,input_date):
        """
            :param begin_date: 开始时间
            :param end_date: 结束时间
            :param date_format: 时间格式化 默认为：%Y%m%d
            :return: begin_date-end_date 中所有的周（周一日期_周日日期）
        """

        biz_date=datetime.strptime(input_date, "%Y-%m-%d").date()

        _prex_date = input_date[0:7]
        _day_of_month=int(input_date[8:])

        if(_day_of_month>15):
            begin_date=_prex_date+'-16'

            max_day=calendar.monthrange(biz_date.year, biz_date.month)[1]

            max_date = datetime(biz_date.year, biz_date.month, max_day)

            current_date = datetime.today()

            if (max_date.__ge__(current_date)):
                 max_date=current_date

            # current_day=int(datetime.now().strftime("%d"))
            # if(max_day>current_day):
            #     max_day=current_day
            end_date = max_date.strftime("%Y-%m-%d")

        else:
            begin_date = _prex_date + '-01'
            end_date = _prex_date + '-15'

        return begin_date+'_'+end_date

    def get_half_month_list_start_and_end(self,begin_date,end_date):
        """
            :param begin_date: 开始时间
            :param end_date: 结束时间
            :param date_format: 时间格式化 默认为：%Y%m%d
            :return: begin_date-end_date 中所有的周（周一日期_周日日期）
        """
        date_list=[]

        list=self.get_date_list(begin_date,end_date)
        for date_str in list:
            result=self.get_half_month_start_and_end(date_str)
            if(result  not  in date_list):
                date_list.append(result)
        return date_list






    def  get_date_list(self,begin_date, end_date):
        if (not begin_date):
                begin_date = self.get_default_begin_date()
        if (not end_date):
                end_date = self.get_default_end_date()
        print("begin_date=" + begin_date + ",end_date=" + end_date)
        date_list = [x.strftime('%Y-%m-%d') for x in list(pd.date_range(start=begin_date, end=end_date))]
        if (len(date_list) > 1):
                date_list.pop()
        return date_list





    def get_multi_date_list(self,begin_date, end_date, date_flag):
        date_list = []
        if (date_flag == 'Daily'):
            date_list = self.get_date_list(begin_date, end_date)
        elif (date_flag == 'Weekly'):

            date_list = self.get_weekday_list_begin_and_end(begin_date, end_date)

        elif (date_flag == 'HalfMonth'):

            date_list = self.get_half_month_list_start_and_end(begin_date, end_date)
        elif (date_flag == 'Month'):
            date_list = self.get_month_list_start_and_end(begin_date, end_date)
        return date_list

if __name__ == "__main__":

    dateh=DateHelper()

    #e=dateh.get_month_start_and_end('2021-07-21')
    #e=dateh.get_month_list_start_and_end('2021-07-21','2021-09-22')
    # half_month=dateh.get_half_month_list_start_and_end('2021-05-01','2021-07-29')
    # print(half_month)
    #week = dateh.get_weekday_list_begin_and_end('20210714','20210922')
    # week = dateh.get_weekday_list_begin_and_end(begin_date='',end_date='')
    # print(week)
    #
    # week = dateh.get_weekday_list_begin_and_end(begin_date='2021-07-23', end_date='2021-07-23')
    # print(week)
    # date = dateh.get_date_list('20210721', '20210922')
    # print(date)
    # half_month = dateh.get_half_month_list_start_and_end(begin_date='', end_date='')
    # print(half_month)
    #
    # half_month = dateh.get_half_month_list_start_and_end('2021-07-01', '2021-07-29')
    # print(half_month)

    # date_list=dateh.get_multi_date_list('2021-07-01','2021-07-23','HalfMonth')
    # print(date_list)
    #
    # half_month = dateh.get_half_month_list_start_and_end('2021-06-30', '2021-07-29')
    # print(half_month)