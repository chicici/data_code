import os

class ReadFileHelper:

   def readSqlFile(self,base_dir,sql_file):

      sql_file_path= os.path.join(base_dir,sql_file)

      
      with open(sql_file_path, encoding='utf-8', mode='r') as fd:
         # 读取整个sql文件，以分号切割。[:-1]删除最后一个元素，也就是空字符串

         res_list=[]
         sql_list = fd.read().split(';')[:-1]

         
         for x in sql_list:
             if(len(x)>5):
                res_list.append(x)
      return res_list


