# -*- coding:UTF-8 -*-
import pymysql


class MysqlHelper:
    def __init__(self, host, port, user, pwd, db):
        self.host = host
        self.port = port
        self.user = user
        self.pwd = pwd
        self.db = db

    def __GetConnect(self):
        if not self.db:
            raise (NameError, "没有设置数据库信息")
        self.conn = pymysql.connect(host=self.host, port=self.port, user=self.user, passwd=self.pwd, db=self.db)

        cur = self.conn.cursor()
        if not cur:
            raise (NameError, "连接数据库失败")
        else:
            return cur

    def execQuery(self, sql):
        cur = self.__GetConnect()
        cur.execute(sql)
        resList = list(cur.fetchall())
        cur.close()
        # 查询完毕后必须关闭连接
        self.conn.close()
        return resList

    def execNonQuery(self, sql):
        cur = self.__GetConnect()
        cur.execute(sql)
        self.conn.commit()
        cur.close()
        self.conn.close()

    def execProc(self, proc_name, args):
        cur = self.__GetConnect()

        cur.callproc(proc_name, args)

        result = cur.fetchall()
        cur.close()
        self.conn.commit()
        cur.close()
        self.conn.close()
        return result
